This is a VST3 audio plugin named Tremolo developed by Jan Wilczek.

To install it on your system:

1. Copy the .vst3 bundle to

    ~/Library/Audio/Plug-Ins/VST3/
    if you're on macOS,

    %LOCALAPPDATA%/Programs/Common/VST3/
    if you're on Windows,

    ~/.vst3/
    if you're on Linux.

    Depending on the operating system, this operation may require elevated permissions.

2. Reload your DAW.

All rights reserved.

